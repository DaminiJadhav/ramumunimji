package com.posbilling.posbillingapplication.lib;

/**
 * Created by Android PC (Ankur) on 28,February,2020
 */
public interface BaseView<T> {
    APIComponent getAPIComponent();
}
