package com.posbilling.posbillingapplication.utility;

public class DataBuisnessName {

/*    ID	Typename
1	Kirana Store
2	Vehicle Service Center
3	Agro Agency
4	Dairy Farm*/

    public static String [] buisnessNamesEnglish={"Kirana Store",
            "Vehicle Service Center",
            "Agro Agency",
            "Dairy Farm"};

    public static String [] buisnessNamesMarathi={"किराणा स्टोअर",
            "वाहन सेवा केंद्र",
            "अॅग्रो एजन्सी",
            "दुग्धशाळा"};


    public static String [] buisnessId={"1",
            "2",
            "3",
            "4"
    };
}
