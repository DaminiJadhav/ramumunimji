package com.posbilling.posbillingapplication.model.response;

public class PurchaseApiResponse {
}
