package com.posbilling.posbillingapplication.model.response;

public class DemoResponseClass {

}


/*
{
        "status":"success",
        "message":"arraylist send",
        "oppositePersonName":"Austrologer one",
        "oppositePersonImage":"http:/....",

        "chatList":[{
        "senderId":"R12",
        "senderName":"Rushikesh",
        "message": "Hello",
        "time" : "12.01"
        "date" : "12/2/2019"
        },
        {
        "senderId":"A1",
        "senderName":"Austrologer one",
        "message": "Hello Rushikesh, How are you ?",
        "time" : "12.05"
        "date" : "12/2/2019"
        },
        {
        "senderId":"R12",
        "senderName":"Rushikesh",
        "message": "I'm fine.",
        "time" : "12.06"
        "date" : "12/2/2019"
        },
        {
        "senderId":"R12",
        "senderName":"Rushikesh",
        "message": "What about you ?",
        "time" : "12.06"
        "date" : "12/2/2019"
        },
        {
        "senderId":"A1",
        "senderName":"Austrologer one",
        "message": "I'm also fine.",
        "time" : "12.07"
        "date" : "12/2/2019"
        },
        {
        "senderId":"A1",
        "senderName":"Austrologer one",
        "message": "How can I help you ?",
        "time" : "12.07"
        "date" : "12/2/2019"
        }
        ]
        }*/
