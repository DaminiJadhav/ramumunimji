package com.posbilling.posbillingapplication.utility;

/**
 * Created by Android PC (Ankur) on 25,February,2020
 */
public interface NavigationFragmentChange {
    void navigationFragmnetchange();
}
