package com.posbilling.posbillingapplication.interfaceclick;

public interface OnContactListClick {
    void OnContactClick(int position);
}