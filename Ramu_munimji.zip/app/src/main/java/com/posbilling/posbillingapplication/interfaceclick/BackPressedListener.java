package com.posbilling.posbillingapplication.interfaceclick;

public interface BackPressedListener {
    void onBackPressedListener();
}
