package com.posbilling.posbillingapplication.interfaceclick;

public interface OnFragmentTabListener {
    void OnFragmentTabListener(int fragNum);
}
