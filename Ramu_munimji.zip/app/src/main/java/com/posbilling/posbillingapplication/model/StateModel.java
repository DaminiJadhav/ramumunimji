package com.posbilling.posbillingapplication.model;

/**
 * Created by Android PC (Ankur) on 27,February,2020
 */
public class StateModel {
    String stateNameMarathi = "";
    String stateNameEnglish = "";
    String stateId = "";

    public String getStateNameMarathi() {
        return stateNameMarathi;
    }

    public void setStateNameMarathi(String stateNameMarathi) {
        this.stateNameMarathi = stateNameMarathi;
    }

    public String getStateNameEnglish() {
        return stateNameEnglish;
    }

    public void setStateNameEnglish(String stateNameEnglish) {
        this.stateNameEnglish = stateNameEnglish;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }
}
