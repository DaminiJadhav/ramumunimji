package com.posbilling.posbillingapplication.interfaceclick;

import android.view.View;

/**
 * Created by Android PC (Ankur) on 28,February,2020
 */
public interface OnRecyclerviewClick {
    void onReclerViewClick(View view , int position);
}
