package com.posbilling.posbillingapplication.interfaceclick;

import android.view.View;

public interface OnMultipleSupplierListener {
    void onMultipleSupplierListener(View view, int position);
}
